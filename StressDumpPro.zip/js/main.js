
function dumpStress() {
    const effect = document.getElementById("effectSelect").value;
    const animation = document.getElementById("animation");
    const sound = document.getElementById("destroySound");

    animation.innerHTML = `<img src='assets/${effect}.gif' alt='effect' style='width:200px;'>`;
    sound.play();

    setTimeout(() => {
        document.getElementById("stressInput").value = "";
        animation.innerHTML = "";
    }, 3000);
}
